export const Secret = "MySecret";
// export const MongoURI  = "mongodb://127.0.0.1/media"
export const MongoURI  = "mongodb+srv://thiago:thiago123@mongocluster.aoylqre.mongodb.net/media1?retryWrites=true&w=majority" 